#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest
import time
import random
import threading
from comm.atc import atLogger, atChat, atConfig, relayCtrl

class OFOTest(unittest.TestCase):
    """ Power on/off, sleep/awake test case """
    name = 'Test for OFO project'

    @classmethod
    def setUpClass(cls):
        atChat.open()
        atLogger.case_start(cls.name)

    @classmethod
    def tearDownClass(cls):
        atLogger.case_end(cls.name)
        atChat.close()
        relayCtrl.close_channel()

    def check_status(self):
        check_timeout = 10.0
        for n in range(20):
            if atChat.send_ok('AT', check_timeout):
                return True
        atLogger.case_log('There may be something wrong with chip!')
        return False

    def sleep_awake(self):
        test_timeout = 30.0

        relayCtrl.close_channel()
        time.sleep(1.0)
        relayCtrl.open_channel()
        if not atChat.send_ok('AT+CSCLK=1', test_timeout):
            atLogger.case_log('Send sleep command failed!')
            time.sleep(1)
            relayCtrl.close_channel()
            return False
        atLogger.case_log('Sleeping...')
        sleeptime = random.randint(600, 1800)
        time.sleep(sleeptime)
        relayCtrl.close_channel()
        atLogger.case_log('Awake!')
        time.sleep(1.0)
        if not atChat.send_ok('AT+CIPSTART="TCP","47.93.154.72",38483', 150) \
                or not atChat.has('CONNECT OK'):
            return False
        time.sleep(1.0)
        if not atChat.send('AT+CIPSEND', 40):
            atChat.send('AT+CIPCLOSE', 40)
            return False
        time.sleep(1.0)
        send_data = 'A0 00 00 01 00 30 46 30 17 01 12 34 57 FF 00 3F 01 01 00 01 00 30 46 30 17 01 12 34 57 FF 00 00 58 68 46 AC 10 32 64 82 01 01 00 00 0E 14 12 34 FF 00 00 00 00 00 00 00 00 00 00 58 68 46 AC 58 68 46 AC 02 00 00 00 00 00 00 00 00 00 00 00 40'
        if not atChat.send_ok(send_data+chr(26), 10):
            atChat.send('AT+CIPCLOSE', test_timeout)
            return False
        time.sleep(1.0)
        if not atChat.send_ok('AT+CIPCLOSE', 40) or \
                not atChat.send_ok('AT+CIPSHUT', 40):
            return False
        return True
    
    def test_sleep_awake(self):
        pass_cnt = 0
        testround = 100
        #test_timeout = 30.0
        #self.assertTrue(atChat.send_ok('AT+CGATT=1', test_timeout))
        self.assertTrue(atChat.send_ok('AT+CGDCONT=1,"IP","CMNET"' , 2))
        self.assertTrue(atChat.send_ok('AT+CGACT=1,1', 40))
        for i in range(testround):                      
            atLogger.case_log('------------Test Round: %s ----------' % str(i+1))
            if not self.sleep_awake():
                if not self.check_status():
                    break
                continue
            pass_cnt += 1
            atLogger.case_log('--Total test round: %s' % str(i+1))
            atLogger.case_log('--Success count: %s' % str(pass_cnt))
            atLogger.case_log('--Fail count: %s' % str(i+1-pass_cnt))
        atLogger.case_log('========================================')
        atLogger.case_log('--Total test round: %s' % str(i+1))
        atLogger.case_log('--Success count: %s' % str(pass_cnt))
        atLogger.case_log('--Fail count: %s' % str(i+1-pass_cnt))
        atLogger.case_log('--FPY: %s' % (str(pass_cnt / testround * 100) + '%'))
        self.assertTrue(pass_cnt == testround)

if __name__ == '__main__':
    unittest.main()
