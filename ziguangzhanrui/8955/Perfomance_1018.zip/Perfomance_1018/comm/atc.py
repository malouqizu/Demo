#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import serial
import ctypes
import datetime
from ctypes import *
from socket import *
#import win32ras
import re
import subprocess


class AtConfig(object):
    """ AT test configuration through env variables
    """
    
    def __init__(self):
        timeNow = time.strftime('%Y%m%d-%H%M%S',time.localtime(time.time()))
        self.log_file_name = os.environ.get('AT_TEST_LOG_FILE', 'log-'+ timeNow + '.txt')
        self.com_port = os.environ.get('AT_TEST_COM', 'COM12')
        self.echo_server = os.environ.get(
            "AT_TEST_ECHO_SERVER", "111.205.140.137")
        self.echo_port = int(os.environ.get("AT_TEST_ECHO_PORT", "11008"))
        self.relay_channel = int(os.environ.get("AT_TEST_RELAY_CHANNEL", "1"))
        self.relay_server = os.environ.get('AT_TEST_RELAY_SERVER', 'localhost')
        self.relay_port = int(os.environ.get('AT_TEST_RELAY_PORT', "9999"))
        self.entry_name = os.environ.get('AT_TEST_PPP_ENTRYNAME', '拨号连接')
        self.ping_addr = os.environ.get('AT_TEST_PING_ADDR', '123.57.221.42')
        self.local_conn_addr = os.environ.get('AT_TEST_LOCAL_CONN_ADDR', '10.102.21.1')


""" Global object """
atConfig = AtConfig()


class AtLogger(object):
    """ Simple logger for AT
        * support both stdout and log file
        * auto add prefix
    """
    def open_file(self, fname):
        if self.fh is not sys.stdout:
            self.fh.close()

        if fname and fname != '-':
            self.fh = open(fname, 'w')
        else:
            self.fh = sys.stdout

    def __init__(self):
        self.fh = None
        try:
            self.fh = open(atConfig.log_file_name, 'w')
        except:
            self.fh = None
        self.start_time = time.time()

    def __del__(self):
        if self.fh is not None:
            self.fh.close()

    def __write(self, out):
        if self.fh is not None:
            self.fh.write(out)
            self.fh.flush()
        sys.stdout.write(out)

    def get_resp(self, line):
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H:%M:%S.%f")[:-3]
        self.__write("[%s]<<< %s\n" % (stamp, line.strip()))

    def send_cmd(self, line):
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H:%M:%S.%f")[:-3]
        self.__write("[%s]>>> %s\n" % (stamp, line.strip()))

    def case_start(self, name):
        self.__write('\n')
        self.__write("=== %s [start] ===\n" % (name.strip()))

    def case_end(self, name):
        self.__write("=== %s [end] ===\n" % (name.strip()))
        self.__write('\n')

    def case_log(self, line):
        self.__write("--- %s\n" % (line.strip()))

    def case_timed_log(self, line):
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H:%M:%S.%f")[:-3]
        self.__write("[%s]--- %s\n" % (stamp, line.strip()))


""" Global object """
atLogger = AtLogger()


class AtChat(object):
    line_checked = ''
    line_contain_checked = ''
    ECHO = 0
    OK = 1
    ERROR = 2

    def __init__(self):
        self.port = atConfig.com_port
        self.baudrate = 115200
        self.bytesize = serial.EIGHTBITS
        self.parity = serial.PARITY_NONE
        self.stopbits = serial.STOPBITS_ONE
        self.xonxoff = False
        self.rtscts = False
        self.dsrdtr = False
        self.timeout = 0.5
        self.write_timeout = 1.0
        self.serial = None
        self.coding = 'utf-8'

        self.resp = []
        self.serial = None
        self.inparsing = bytearray()
        self.last_cmd = ''

    def open(self):
        """ Open the serial port, and start a thread to read from the serial port
        """

        if self.serial is not None:
            return

        self.serial = serial.Serial(port=self.port,
                                    baudrate=self.baudrate,
                                    parity=self.parity,
                                    stopbits=self.stopbits,
                                    xonxoff=self.xonxoff,
                                    rtscts=self.rtscts,
                                    dsrdtr=self.dsrdtr,
                                    timeout=self.timeout,
                                    write_timeout=self.write_timeout)

    def close(self):
        """ Close the serial port
        """
        self.serial.close()
        self.serial = None

    def reopen(self):
        """ Reopen the serial port
        """
        if self.serial is not None:
            self.close()
        self.open()

    def sleep(self, seconds):
        """ Helper function to sleep a while, and always return True
        """
        time.sleep(seconds)
        return True

    def send(self, cmd, timeout):
        """ Send an AT commmand, read responses till either OK or ERROR
            * \r\n will be appended to command automatically
            * the command is save for later checking
            * all responses are saved for later checking

            NOTE: even ERROR is read, this function will return True
        """
        global atLogger
        if not self.serial:
            raise Exception("!!! Serial port isn't open")

        atLogger.send_cmd(cmd)
        self.last_cmd = cmd.strip()
        self.resp.clear()

        self.serial.reset_input_buffer()
        self.serial.reset_output_buffer()
        self.serial.write((cmd + "\r\n").encode())
        return self.__read_resp(timeout, AtChat.__check_ok_error)

    def send_ok(self, cmd, timeout):
        """ Send an AT commmand, and check response OK """
        return self.send(cmd, timeout) and self.has(self.OK)

    def wait(self, line, timeout):
        """ Read responses till the specified line
            All responses are saved for later checking
        """
        if not self.serial:
            raise Exception("!!! Serial port isn't open")

        AtChat.line_checked = line
        self.resp.clear()
        return self.__read_resp(timeout, AtChat.__check_line)

    def contain(self, line):
        """Whether responses contain line
        """
        AtChat.line_contain_checked = line
        for res in self.resp:
            if self.__check_expect(res, AtChat._check_contain_line):
                return True
        return False

    def has(self, expected):
        """ Whether responses has the specified line
        """
        for res in self.resp:
            if self.__check_expect(res, expected):
                return True
        return False

    def has_in_order(self, *expected):
        """ Whether the sequence appears in order
        """
        count = len(expected)
        n = 0
        check = expected[n]
        for res in self.resp:
            if self.__check_expect(res, check):
                n += 1
                if n == count:
                    break
                check = expected[n]
        return n == count

    def get_line_starts(self, line):
        """ Return the first response started with line
        """
        for res in self.resp:
            if res.startswith(line):
                return res
        return None

    def get_uptime(self):
        """ Get module up time by AT command, and return -1 on fail
        """
        if not atChat.send_ok("AT^UPTIME", 1.0):
            return -1.0

        line = atChat.get_line_starts("^UPTIME:")
        if line is None:
            return -1.0
        return int(line.split()[1]) / 1000.0

    def get_csq(self):
        """ Get CSQ by AT command, and return -1 on fail
        """
        if not atChat.send_ok("AT+CSQ", 1.0):
            return -1

        line = atChat.get_line_starts("+CSQ:")
        if line is None:
            return -1
        return int(line.split()[1].split(',')[0])

    def __check_expect(self, line, check):
        """ Check a line. The condition can be
            * integer (OK, ERROR, ECHO)
            * string: match a line
            * callable: return True/False
        """
        if callable(check):
            return check(line)
        elif type(check) == int:
            if check == self.ECHO:
                return line == self.last_cmd
            elif check == self.OK:
                return line == 'OK'
            elif check == self.ERROR:
                return line.startswith('+CME ERROR:')
        elif type(check) == str:
            return line == check
        return False

    @staticmethod
    def __check_ok_error(line):
        return line == 'OK' or line == 'CLOSE OK' or line.startswith('+CME ERROR:') or line.startswith('>')

    @staticmethod
    def __check_line(line):
        return line == AtChat.line_checked

    @staticmethod
    def _check_contain_line(line):
        return AtChat.line_contain_checked in line

    def __read_resp(self, timeout, expected):
        """ Read responses till timeout or expected is satisfied
        """
        if timeout is not None:
            endtime = time.time() + timeout

        while True:
            if timeout is not None and time.time() > endtime:
                return False

            raw = self.serial.read(1)
            if len(raw) == 0:
                continue

            self.inparsing.extend(raw)
            size = len(self.inparsing)
            if len(self.inparsing) < 2:
                continue

            if self.inparsing[-2] == ord('\r') and self.inparsing[-1] == ord('\n'):
                line = self.inparsing.decode(self.coding, 'ignore').strip()
                self.inparsing.clear()
                atLogger.get_resp(line)
                self.resp.append(line)
                if expected(line):
                    return True


""" Global object """
atChat = AtChat()


class RelayControl(object):
    """ Open/close relay channel through socket """

    def __init__(self):
        self.host = atConfig.relay_server
        self.port = atConfig.relay_port
        self.bufsize = 1024
        self.addr = (self.host, self.port)

    def __conn_host(self, masg):
        client = socket(AF_INET, SOCK_STREAM)
        client.connect(self.addr)
        client.send(masg.strip().encode())
        data = client.recv(self.bufsize).decode()
        if 'OK' not in data:
            client.close()
            raise Exception("Error when %s" % masg)
        client.close()

    def open_channel(self, index=atConfig.relay_channel):
        self.__conn_host('open %d' % index)

    def close_channel(self, index=atConfig.relay_channel):
        self.__conn_host('close %d' % index)


""" Global object"""
relayCtrl = RelayControl()
