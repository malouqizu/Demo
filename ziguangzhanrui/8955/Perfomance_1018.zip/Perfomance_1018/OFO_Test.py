#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import unittest
import time
import random
import threading
from comm.atc import atLogger, atChat, atConfig, relayCtrl

class OFOTest(unittest.TestCase):
    """ Power on/off, sleep/awake test case """
    name = 'Test for OFO project'

    @classmethod
    def setUpClass(cls):
        atChat.open()
        atLogger.case_start(cls.name)

    @classmethod
    def tearDownClass(cls):
        atLogger.case_end(cls.name)
        atChat.close()
        relayCtrl.close_channel()

    def test_poweronoff(self):
        pass_cnt = 0
        testround = 10000
        test_timeout = 20.0
        for i in range(testround):
            atLogger.case_log('------------Test Round: %s ----------' % str(i+1))
            relayCtrl.close_channel()
            atChat.reopen()
            time.sleep(1.0)
            relayCtrl.open_channel()
            if not atChat.wait('+CREG: 1', 30.0):
                continue

            if not atChat.send_ok('ATE0', test_timeout):
                continue
            time.sleep(2)
            if not atChat.send('AT+CPIN?', 40) or \
                    not atChat.has('+CPIN:READY'):
                continue
            time.sleep(1)
            if not atChat.send('AT+CGREG?', 30) or \
                    not atChat.get_line_starts('+CGREG:'):
                continue
            time.sleep(1)
            if not atChat.send('AT+CSQ', test_timeout) or \
                    not atChat.get_line_starts('+CSQ:'):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CIMI', 40):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CGSN', test_timeout):
                continue
            time.sleep(1)
            if not atChat.send('AT+CCED=0,1', 60) or \
                    not atChat.get_line_starts('+CCED:'):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CGMM', test_timeout):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CGMR', test_timeout):
                continue
            time.sleep(1)
            if not atChat.send_ok('ATV1', test_timeout):
                continue
            time.sleep(1)
            if not atChat.send('AT+CGREG?', test_timeout) or \
                    not atChat.get_line_starts('+CGREG:'):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CGACT=0,1', 40):
                continue
            if not atChat.send('AT+CGACT?', test_timeout) or \
                    not atChat.contain(',0'):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CGDCONT=1,"IP","CMNET"', test_timeout):
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CGACT=1,1', 40):
                continue
            time.sleep(1)
            if not atChat.send('AT+CGPADDR=1', test_timeout) or \
                    not atChat.contain('.'):
                continue
            time.sleep(1)
            if not atChat.send('AT+CSQ', test_timeout) or \
                    not atChat.get_line_starts('+CSQ:'):
                continue
            time.sleep(1)
            if not atChat.send('AT+CCED=0,1', 60) or \
                    not atChat.get_line_starts('+CCED:'):
                continue
            time.sleep(1)
            if not atChat.send('AT+CIPSTART="TCP","47.93.154.72",38483', 150) \
                    or not atChat.has('CONNECT OK'):
                continue
            time.sleep(1)
            if not atChat.send('AT+CIPSEND', 40):
                atChat.send_ok('AT+CIPCLOSE', 40)
                continue
            time.sleep(1)
            send_data = 'A0 00 00 01 00 30 46 30 17 01 12 34 57 FF 00 3F 01 01 00 01 00 30 46 30 17 01 12 34 57 FF 00 00 58 68 46 AC 10 32 64 82 01 01 00 00 0E 14 12 34 FF 00 00 00 00 00 00 00 00 00 00 58 68 46 AC 58 68 46 AC 02 00 00 00 00 00 00 00 00 00 00 00 40'
            if not atChat.send_ok(send_data+chr(26), 10):
                atChat.send_ok('AT+CIPCLOSE', 40)
                continue
            time.sleep(1)
            if not atChat.send_ok('AT+CIPCLOSE', 40) or \
                    not atChat.send_ok('AT+CIPSHUT', 40):
                continue
            time.sleep(1)
            pass_cnt += 1
            atLogger.case_log('--Total test round: %s' % str(i+1))
            atLogger.case_log('--Success count: %s' % str(pass_cnt))
        atLogger.case_log('========================================')
        atLogger.case_log('--Total test round: %s' % str(testround))
        atLogger.case_log('--Success count: %s' % str(pass_cnt))
        atLogger.case_log('--FPY: %s' % (str(pass_cnt / testround * 100) + '%'))
        self.assertTrue(pass_cnt == testround)

if __name__ == '__main__':
    unittest.main()
