#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import unittest
import time
import datetime
import random
import threading
from comm.atc import atLogger, atChat, atConfig

def myapn_str():
     str = 'CMNET'
     atChat.send('at+cops?', 40.0)
     if atChat.has('+COPS: 0,2,"46001"'):
         str = 'UNINET'
     elif atChat.has('+COPS: 0,2,"46000"'):
         str = 'CMNET'
     return str

class Tcpip(unittest.TestCase):
    """ Tcpip service connect and disconnect test case """
    name = 'Connect and disconnect TCP'

    @classmethod
    def setUpClass(cls):
        atChat.open()
        dir = os.getcwd()
        timeStamp = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d-%H-%M-%S')
        atLogger.open_file(dir + r'\log\tcpip-' + timeStamp + '.log')
        atLogger.case_start(cls.name)

    @classmethod
    def tearDownClass(cls):
        atLogger.case_end(cls.name)
        atChat.close()

    def test1_tcpconnect(self):
        connectavgtime = 0
        connectmaxtime = 0
        connectmintime = 1000
        connectsumtime = 0
        connectsuccesscnt = 0
        testround = 10
        #test_timeout = 30.0
        self.assertTrue(atChat.send('AT+CGATT=1', 40.0))
        self.assertTrue(atChat.has('OK'))
        APN = myapn_str()
        self.assertTrue(atChat.send('AT+CGDCONT=1,"IP","'+ APN +'"', 40.0))
        self.assertTrue(atChat.has('OK'))
        self.assertTrue(atChat.send('AT+CGACT=1', 40.0))
        self.assertTrue(atChat.has('OK'))
        for i in range(testround):
            atLogger.case_log('------------TCP connect test Round: %s ----------' % str(i+1))
            time.sleep(1.0)
            starttime = time.time()
            if not atChat.send('AT+CIPSTART="TCP","111.205.140.137",11008', 40.0) or \
                    not atChat.has('OK'):
                continue
            if not atChat.wait('CONNECT OK', 30.0):
                continue
            endtime = time.time()

            connectsuccesscnt += 1
            connectsumtime += (endtime - starttime)
            connectavgtime = connectsumtime / connectsuccesscnt
            if (endtime - starttime) > connectmaxtime:
                connectmaxtime = endtime - starttime
            if (endtime - starttime) < connectmintime:
                connectmintime = endtime - starttime
            atLogger.case_log('Time cost of connect TCP: %ss' % str(endtime - starttime))
            if not atChat.send('AT+CIPCLOSE', 30.0):
                    #not atChat.has('CLOSE OK'):
               while True:
                    if not atChat.has('CLOSE OK'):
                        break
                    if not atChat.get_line_starts('+CME ERROR:'):
                        atChat.send('AT+CIPCLOSE', 30.0)
                        if atChat.has('CLOSE OK'):
                            break         
                
                #continue
            atLogger.case_log('Time cost of connect TCP: %ss' % str(endtime - starttime))
        atLogger.case_log('Total test round: %s' % str(testround))
        atLogger.case_log('TCP connect success count: %s' % str(connectsuccesscnt))
        atLogger.case_log('TCP connect FPY: %s' % (str(connectsuccesscnt / testround * 100) + '%'))
        atLogger.case_log('Average time cost of connect TCP is: %ss' % str(connectavgtime))
        atLogger.case_log('Max time cost of connect TCP is: %ss' % str(connectmaxtime))
        atLogger.case_log('Min time cost of connect TCP is: %ss' % str(connectmintime))
        self.assertTrue(connectsuccesscnt == testround)

    def test2_tcpdisconnect(self):
        disconnectavgtime = 0
        disconnectmaxtime = 0
        disconnectmintime = 1000
        disconnectsumtime = 0
        disconnectsuccesscnt = 0
        testround = 10
        #test_timeout = 30.0
        self.assertTrue(atChat.send('AT+CGATT=1', 40.0))
        self.assertTrue(atChat.has('OK'))
        APN = myapn_str()
        self.assertTrue(atChat.send('AT+CGDCONT=1,"IP","'+ APN +'"', 40.0))
        self.assertTrue(atChat.has('OK'))
        self.assertTrue(atChat.send('AT+CGACT=1', 40.0))
        self.assertTrue(atChat.has('OK'))
        for i in range(testround):
            atLogger.case_log('------------TCP connect test Round: %s ----------' % str(i+1))
            time.sleep(1.0)
            if not atChat.send('AT+CIPSTART="TCP","111.205.140.137",11008', 40.0) or \
                    not atChat.has('OK'):
                continue
            if not atChat.wait('CONNECT OK', 30.0):
            #if not atChat.contain('CONNECT'):
                continue

            starttime = time.time()
            if not atChat.send('AT+CIPCLOSE', 10.0) or \
                    not atChat.has('CLOSE OK'):
                continue
            endtime = time.time()
            disconnectsuccesscnt += 1
            disconnectsumtime += (endtime - starttime)
            disconnectavgtime = disconnectsumtime / disconnectsuccesscnt
            if (endtime - starttime) > disconnectmaxtime:
                disconnectmaxtime = endtime - starttime
            if (endtime - starttime) < disconnectmintime:
                disconnectmintime = endtime - starttime
            atLogger.case_log('Time cost of disconnect TCP: %ss' % str(endtime - starttime))
        atLogger.case_log('Total test round: %s' % str(testround))
        atLogger.case_log('TCP disconnect success count: %s' % str(disconnectsuccesscnt))
        atLogger.case_log('TCP disconnect FPY: %s' % (str(disconnectsuccesscnt / testround * 100) + '%'))
        atLogger.case_log('Average time cost of disconnect TCP is: %ss' % str(disconnectavgtime))
        atLogger.case_log('Max time cost of disconnect TCP is: %ss' % str(disconnectmaxtime))
        atLogger.case_log('Min time cost of disconnect TCP is: %ss' % str(disconnectmintime))
        self.assertTrue(disconnectsuccesscnt == testround)


if __name__ == '__main__':
    unittest.main()
